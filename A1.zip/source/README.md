# core_A1 #

- 实现了从 **inst_fetch**, **decoder**, **LSU** 到 **ROB** 收集例外 `has_excp|excp_code` 的正向通路.

- 实现了 **ROB.mask** 对例外的"顶格退休", 实现了 **PC** 的 `flush_excp` 例外跳转.

- 增加 **CSRQ**, 至此变为六发射, 对应修改了 **sRAT**, **issue_queue**, **PRF**, **ROB** 的 CDB 总线.

- 接入 **csr_wrapper**, 此时除 `ETRN`, `IDLE` 未实现外, 形式上均已闭合.

- 实现 `ERTN`, 在 **ROB** 内增加 `isERTN` 标识, `ERTN` 退休复刻 `Branch` 只推休第一个的做法, 传给 **CTRL** 产生 `flush_ertn`.

- 修复了 **CSRQ** 内部 `valid_Pj`, `valid_Pd_old` 的旁路写入.

- 加入气泡排除机制, **IFIFO** 发送指令时携带 `ready_pc` 标识, 气泡将无法写入 **ROB**. 本意是后面实现 `IDLE` 用 `interrupt` 唤醒时, 不在前面气泡中插入中断例外, 结果意外发现测例速度大幅提高.

- 实现 `IDLE`, 在 **ROB.mask** 内顶格退休, **PC** 跳转至 `pc_rob+4` 后陷入 stall, `idle_lock` 在 **CTRL** 内部实现.